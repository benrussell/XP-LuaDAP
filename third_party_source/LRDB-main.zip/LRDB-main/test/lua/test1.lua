local value = 1
function testfn(arg)
local local_array = {4234.3,value,"abc",{}}
local local_table = {key1=4234.3,key2=value,key3="abc",key4={3,4,5,6,5}}
local local_value3 = 4234.33
local local_value4 ={4234.3}
end

testfn(2)
