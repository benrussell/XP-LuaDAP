local _ENV={envvar=5456}
local local_value1=1
local local_value2=2
local local_value3={3}
