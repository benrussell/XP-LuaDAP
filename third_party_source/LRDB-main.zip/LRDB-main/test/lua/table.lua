local t = {}
t[1000] = "hi"
local t2 = {}